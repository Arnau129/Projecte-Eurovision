/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eurovision;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class FuncionsTest {

    public FuncionsTest() {
    }

    /**
     * Test of EscollirWinners method, of class Funcions.
     */
    @Test
    public void testEscollirWinners() {
        System.out.println("EscollirWinners");
        final int WINNER = 0;
        int[][] premis = null;
        for (int i = 0; i < premis[WINNER].length; i++) {
            premis[WINNER][i] = i;
        }

        int[] expResult = {25};
        int[] result = Funcions.EscollirWinners(premis);
        assertArrayEquals(expResult, result);
    }

    @Test
    public void testEscollirWinnersMesGuanyadors() {
        System.out.println("EscollirWinners");
        final int WINNER = 0;
        int[][] premis = null;
        for (int i = 0; i < premis[WINNER].length - 1; i++) {
            premis[WINNER][i] = i;
        }
        premis[WINNER][premis[WINNER].length - 1] = premis[WINNER].length - 2;
        int[] expResult = {24, 25};
        int[] result = Funcions.EscollirWinners(premis);
        assertArrayEquals(expResult, result);
    }

    /**
     * Test of EscollirLoosers method, of class Funcions.
     */
    @Test
    public void testEscollirLoosers() {
        System.out.println("EscollirLoosers");
        final int LOSER = 1;
        int[][] premis = null;
        for (int i = 0; i < premis[LOSER].length; i++) {
            premis[LOSER][i] = i;
        }
        premis[LOSER][1] = 0;
        int[] expResult = {0, 1};
        int[] result = Funcions.EscollirLoosers(premis);
        assertArrayEquals(expResult, result);
    }

    @Test
    public void testEscollirLoosersMesLoosers() {
        System.out.println("EscollirLoosers");
        final int LOSER = 1;
        int[][] premis = null;
        for (int i = 0; i < premis[LOSER].length; i++) {
            premis[LOSER][i] = i;
        }

        int[] expResult = {0};
        int[] result = Funcions.EscollirLoosers(premis);
        assertArrayEquals(expResult, result);
    }

    /**
     * Test of NumeroWinnersLoosers method, of class Funcions.
     */
    @Test
    public void testNumeroWinners() {
        System.out.println("NumeroWinnersLoosers");
        int[][] premis = null;
        int numero = 4;
        int winnerlooser = 0;
        for (int i = 0; i < premis[winnerlooser].length; i++) {
            premis[winnerlooser][i] = i;
        }
        int expResult = 1;
        int result = Funcions.NumeroWinnersLoosers(premis, numero, winnerlooser);
        assertEquals(expResult, result);
    }

    @Test
    public void testNumeroWinnersMesGuanyadors() {
        System.out.println("NumeroWinnersLoosers");
        int[][] premis = null;
        int numero = 4;
        int winnerlooser = 0;
        for (int i = 0; i < premis[winnerlooser].length; i++) {
            premis[winnerlooser][i] = i;
        }
        premis[winnerlooser][0] = 4;
        int expResult = 2;
        int result = Funcions.NumeroWinnersLoosers(premis, numero, winnerlooser);
        assertEquals(expResult, result);
    }

    /**
     * Test of NumeroWinnersLoosers method, of class Funcions.
     */
    @Test
    public void testNumeroLoosers() {
        System.out.println("NumeroWinnersLoosers");
        int[][] premis = null;
        int numero = 3;
        int winnerlooser = 1;
        for (int i = 0; i < premis[winnerlooser].length; i++) {
            premis[winnerlooser][i] = i;
        }
        int expResult = 1;
        int result = Funcions.NumeroWinnersLoosers(premis, numero, winnerlooser);
        assertEquals(expResult, result);
    }

    @Test
    public void testNumeroLoosersMesLoosers() {
        System.out.println("NumeroWinnersLoosers");
        int[][] premis = null;
        int numero = 6;
        int winnerlooser = 1;
        for (int i = 0; i < premis[winnerlooser].length; i++) {
            premis[winnerlooser][i] = i;
        }
        premis[winnerlooser][0] = 6;
        int expResult = 2;
        int result = Funcions.NumeroWinnersLoosers(premis, numero, winnerlooser);
        assertEquals(expResult, result);
    }
}
