/*
El programa principal definirà la estructura de dades per a emmagatzemar el total de
països que participen en la final (26 països), i li demanarà a l'usuari que ompli els seus
noms (només els noms), inicialitzant el comptador de vots a 0 per a cada país.
 */
package eurovision;

import java.util.Scanner;
import utils.Utils;

class Pais {

    public String nom;
    public int vots;
    
    Pais(String nom, int vots)
    {
        this.nom = nom;
        this.vots = vots;
    }
    
    public void mostrarVotsPais()
    {
        System.out.println("El pais "+nom+" té "+vots+" vots.");
    }
};

public class Eurovision {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        final int NUMPAISOS = 26;
        Pais[] pais = new Pais[NUMPAISOS];
        for (int i = 0; i < pais.length; i++) {
            System.out.print("Introdueix el nom del pais: ");
            String nomPais = scan.nextLine();
            pais[i] = new Pais(nomPais, 0);
            
        }
        votar(pais);
    }
    
    static void votar(Pais[] pais) {
        
       for (int i = 0; i < pais.length; i++) {
            pais[i].mostrarVotsPais();
        }
    }

}
